import uuid
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import SQLAlchemyError
from starlette.concurrency import run_in_threadpool
from app.api import auth, me, teams, admin_users, health
from app.schemas.auth import ServiceError
from app.services import rate_limits
from app.services.team_members import utcnow

PUBLIC_AUTH = {
    "/api/auth/account-status",
    "/api/auth/register-by-invite",
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/complete-registration-after-unlock",
}


def error_response(request, code, status):
    headers = {"Cache-Control": "no-store"}
    if status == 429:
        headers["Retry-After"] = "60"
    return JSONResponse(
        {
            "error": {
                "code": code,
                "message": "Please contact Admin"
                if status == 403
                else "Request could not be completed",
                "request_id": getattr(request.state, "request_id", ""),
            }
        },
        status_code=status,
        headers=headers,
    )


class UTCJSONResponse(JSONResponse):
    def render(self, content):
        def normalize(value):
            if isinstance(value, dict):
                return {
                    key: (
                        item + "Z"
                        if key
                        in {
                            "created_at",
                            "updated_at",
                            "joined_at",
                            "removed_at",
                            "claimed_at",
                            "expires_at",
                        }
                        and isinstance(item, str)
                        and "T" in item
                        and not item.endswith("Z")
                        and "+" not in item
                        else normalize(item)
                    )
                    for key, item in value.items()
                }
            if isinstance(value, list):
                return [normalize(item) for item in value]
            return value

        return super().render(normalize(content))


def create_app():
    app = FastAPI(
        title="Vegent Identity",
        default_response_class=UTCJSONResponse,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    @app.exception_handler(ServiceError)
    async def service_error_handler(request, exc):
        return error_response(request, exc.code, exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request, exc):
        return error_response(request, "VALIDATION_ERROR", 422)

    @app.exception_handler(SQLAlchemyError)
    async def database_error_handler(request, exc):
        return error_response(request, "SERVICE_UNAVAILABLE", 503)

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request, exc):
        return error_response(request, "INTERNAL_ERROR", 500)

    @app.middleware("http")
    async def public_auth_admission(request, call_next):
        request.state.request_id = str(uuid.uuid4())
        try:
            if request.url.path in PUBLIC_AUTH:
                request.state.source_ip = rate_limits.trusted_source_ip(
                    request.scope.get("aws.event", {})
                )
                await run_in_threadpool(
                    rate_limits.admit_auth_attempt,
                    None,
                    request.state.source_ip,
                    now=utcnow(),
                )
                await run_in_threadpool(
                    rate_limits.cleanup_expired_counters, now=utcnow()
                )
            response = await call_next(request)
        except ServiceError as exc:
            return error_response(request, exc.code, exc.status_code)
        except SQLAlchemyError:
            return error_response(request, "SERVICE_UNAVAILABLE", 503)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    for router in (
        auth.router,
        me.router,
        teams.router,
        admin_users.router,
        health.router,
    ):
        app.include_router(router)
    return app


app = create_app()
