import ssl
import threading
from pathlib import Path
from sqlalchemy import create_engine, event, URL
from sqlalchemy.orm import sessionmaker
from app.core.config import get_identity_secret

_lock = threading.Lock()
_engine = None
_credentials = None


def get_engine():
    global _engine, _credentials
    secret = get_identity_secret()
    credentials = (
        secret.DATABASE_HOST,
        secret.DATABASE_PORT,
        secret.DATABASE_NAME,
        secret.DATABASE_USER,
        secret.DATABASE_PASSWORD.get_secret_value(),
    )
    with _lock:
        if _engine is None or credentials != _credentials:
            if _engine is not None:
                _engine.dispose()
            context = ssl.create_default_context(
                cafile=str(Path(__file__).parents[2] / "certs/rds-ca-bundle.pem")
            )
            url = URL.create(
                "mysql+pymysql",
                username=credentials[3],
                password=credentials[4],
                host=credentials[0],
                port=credentials[1],
                database=credentials[2],
            )
            _engine = create_engine(
                url,
                pool_size=1,
                max_overflow=0,
                pool_timeout=2,
                pool_pre_ping=True,
                pool_recycle=300,
                isolation_level="READ COMMITTED",
                hide_parameters=True,
                connect_args={
                    "ssl": context,
                    "connect_timeout": 2,
                    "read_timeout": 3,
                    "write_timeout": 3,
                },
            )

            @event.listens_for(_engine, "connect")
            def configure(connection, record):
                with connection.cursor() as cursor:
                    cursor.execute("SET time_zone = '+00:00'")
                    cursor.execute("SET SESSION innodb_lock_wait_timeout = 2")

            _credentials = credentials
        return _engine


def get_session_factory():
    return sessionmaker(get_engine(), expire_on_commit=False)


def get_db():
    with get_session_factory()() as session:
        yield session


def dispose_engine():
    global _engine
    with _lock:
        if _engine is not None:
            _engine.dispose()
        _engine = None
