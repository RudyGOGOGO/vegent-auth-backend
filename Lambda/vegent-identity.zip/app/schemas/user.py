from dataclasses import dataclass
from pydantic import Field, field_validator
from app.schemas.auth import DTO, EmailRequest
from app.schemas.roles import GlobalRole


@dataclass(frozen=True)
class Actor:
    user_id: int
    user_name: str
    token_version: int
    request_id: str


class ProfileUpdate(DTO):
    display_name: str | None = Field(default=None, max_length=100)
    bio: str | None = Field(default=None, max_length=4000)

    @field_validator("display_name")
    @classmethod
    def nonnull_name(cls, value):
        if value is None:
            raise ValueError("Invalid name")
        return value


class EmailUpdate(EmailRequest):
    pass


class GlobalRoleUpdate(DTO):
    role: GlobalRole


class UserView(DTO):
    id: int
    user_name: str
    email: str
    display_name: str | None
    bio: str | None
    role: str
    auth_source: str
    is_active: bool
