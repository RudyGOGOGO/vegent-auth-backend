from fastapi import APIRouter, Depends, Query, Response
from app.db.session import get_db
from app.core.security import get_current_user
from app.schemas.user import Actor
from app.schemas.team import (
    TeamCreate,
    TeamUpdate,
    InvitationCreate,
    InvitationAccept,
    TeamRoleUpdate,
)
from app.schemas.auth import DTO
from app.services import team_members as teams, invitations, registration

router = APIRouter(prefix="/api/teams")


@router.get("")
def list_teams(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.list_teams(actor, page, limit, db=db)


@router.post("", status_code=201)
def create_team(
    body: TeamCreate, actor: Actor = Depends(get_current_user), db=Depends(get_db)
):
    return teams.create_team(actor, body.team_name, body.description, db=db)


@router.get("/{team_id}")
def get_team(
    team_id: int, actor: Actor = Depends(get_current_user), db=Depends(get_db)
):
    return teams.get_team(actor, team_id, db=db)


@router.put("/{team_id}")
def update_team(
    team_id: int,
    body: TeamUpdate,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.update_team(actor, team_id, body, db=db)


@router.post("/{team_id}/deactivate")
def deactivate_team(
    team_id: int,
    body: DTO,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.deactivate_team(actor, team_id, db=db)


@router.get("/{team_id}/members")
def list_members(
    team_id: int,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.list_members(actor, team_id, page, limit, db=db)


@router.get("/{team_id}/members/history")
def list_history(
    team_id: int,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.list_member_history(actor, team_id, page, limit, db=db)


@router.get("/{team_id}/invitations")
def list_invitations(
    team_id: int,
    status: str | None = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return invitations.list_invitations(actor, team_id, status, page, limit, db=db)


@router.post("/{team_id}/invitations", status_code=201)
def create_invitation(
    team_id: int,
    body: InvitationCreate,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    row, token = invitations.create_invitation(
        actor,
        team_id,
        body.invitee_name,
        body.invitee_email,
        body.invitee_bio,
        body.team_role,
        actor.user_id,
        db=db,
    )
    return {"invitation": row, "invite_token": token}


@router.post("/{team_id}/invitations/accept", status_code=201)
def accept_invitation(
    team_id: int,
    body: InvitationAccept,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return registration.accept_invitation(
        actor, team_id, body.invite_token.get_secret_value(), db=db
    )


@router.post("/{team_id}/invitations/{invitation_id}/revoke")
def revoke_invitation(
    team_id: int,
    invitation_id: int,
    body: DTO,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return invitations.revoke_invitation(actor, team_id, invitation_id, db=db)


@router.post("/{team_id}/invitations/{invitation_id}/resend")
def resend_invitation(
    team_id: int,
    invitation_id: int,
    body: DTO,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    row, token = invitations.resend_invitation(actor, team_id, invitation_id, db=db)
    return {"invitation": row, "invite_token": token}


@router.put("/{team_id}/members/{member_id}/role")
def change_role(
    team_id: int,
    member_id: int,
    body: TeamRoleUpdate,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    return teams.change_team_role(actor, team_id, member_id, body.team_role, db=db)


@router.delete("/{team_id}/members/{member_id}", status_code=204)
def remove_member(
    team_id: int,
    member_id: int,
    actor: Actor = Depends(get_current_user),
    db=Depends(get_db),
):
    teams.remove_member(actor, team_id, member_id, db=db)
    return Response(status_code=204)
