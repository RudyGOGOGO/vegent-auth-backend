from fastapi import APIRouter, Depends
from app.db.session import get_db
from app.core.security import get_current_user
from app.schemas.user import Actor, ProfileUpdate
from app.services import auth

router = APIRouter(prefix="/api/me")


@router.get("")
def get_me(actor: Actor = Depends(get_current_user), db=Depends(get_db)):
    return auth.get_me(actor, db=db)


@router.put("")
def update_me(
    body: ProfileUpdate, actor: Actor = Depends(get_current_user), db=Depends(get_db)
):
    return auth.update_me(actor, body, db=db)
