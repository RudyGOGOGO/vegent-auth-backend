from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.security import get_current_user, verify_bootstrap_iam, normalize_email
from app.schemas.auth import (
    AccountStatusRequest,
    RegisterRequest,
    LoginRequest,
    ServiceError,
    RefreshRequest,
    UnlockCompletionRequest,
    LogoutRequest,
    BootstrapRequest,
)
from app.schemas.user import Actor
from app.services import (
    auth,
    registration,
    unlock,
    admin_password_bootstrap,
    rate_limits,
)
from app.services.team_members import utcnow

router = APIRouter(prefix="/api/auth")


def email_admission(email, request):
    rate_limits.admit_auth_attempt(
        normalize_email(email),
        request.state.source_ip,
        now=utcnow(),
        ip_already_admitted=True,
    )


@router.post("/account-status")
def account_status(
    body: AccountStatusRequest, request: Request, db: Session = Depends(get_db)
):
    email_admission(body.email, request)
    return auth.account_status(body.email, db=db)


@router.post("/register-by-invite", status_code=201)
def register_by_invite(
    body: RegisterRequest, request: Request, db: Session = Depends(get_db)
):
    email_admission(body.email, request)
    return registration.register_by_invite(
        body.email,
        body.password.get_secret_value(),
        body.invite_token.get_secret_value(),
        db=db,
    )


@router.post("/login")
def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    email_admission(body.email, request)
    try:
        return auth.login(body.email, body.password.get_secret_value(), db=db)
    except ServiceError as exc:
        if exc.status_code == 401:
            rate_limits.record_login_failure(
                normalize_email(body.email), request.state.source_ip, now=utcnow()
            )
        raise


@router.post("/refresh")
def refresh(body: RefreshRequest, request: Request, db: Session = Depends(get_db)):
    from sqlalchemy import select
    from app.models.user import User
    from app.models.refresh_token import RefreshToken
    from app.core.security import hash_proof

    with rate_limits.get_session_factory()() as lookup:
        email = lookup.scalar(
            select(User.email)
            .join(RefreshToken, RefreshToken.user_id == User.id)
            .where(
                RefreshToken.token_hash
                == hash_proof("refresh", body.refresh_token.get_secret_value())
            )
        )
    if email:
        email_admission(email, request)
    return auth.refresh(body.refresh_token.get_secret_value(), db=db)


@router.post("/complete-registration-after-unlock")
def complete_registration(
    body: UnlockCompletionRequest, request: Request, db: Session = Depends(get_db)
):
    email_admission(body.email, request)
    return unlock.complete_registration_after_unlock(
        body.email,
        body.new_password.get_secret_value(),
        body.unlock_token.get_secret_value(),
        db=db,
    )


@router.post("/logout", status_code=204)
def logout(
    body: LogoutRequest,
    actor: Actor = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    auth.logout(actor, body.refresh_token.get_secret_value(), db=db)
    return Response(status_code=204)


@router.post("/admin-password/setup")
def setup_admin_password(
    body: BootstrapRequest, request: Request, db: Session = Depends(get_db)
):
    principal = verify_bootstrap_iam(request)
    return admin_password_bootstrap.setup_initial_admin_password(
        body.password.get_secret_value(), principal, db=db
    )
