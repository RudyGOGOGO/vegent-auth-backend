from sqlalchemy import (
    Column,
    Integer,
    BigInteger,
    Text,
    Computed,
    UniqueConstraint,
    ForeignKeyConstraint,
    CheckConstraint,
    Index,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR, CHAR
from app.db.base import Base


class Invitation(Base):
    __tablename__ = "invitations"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    team_id = Column(BigInteger, nullable=False)
    invitee_name = Column(VARCHAR(100), nullable=False)
    invitee_email = Column(VARCHAR(100, collation="utf8mb4_bin"), nullable=False)
    invitee_bio = Column(Text, nullable=True)
    team_role = Column(VARCHAR(20), nullable=False)
    invited_by_user_id = Column(Integer, nullable=False)
    status = Column(VARCHAR(20), nullable=False, server_default=text("'pending'"))
    invite_token_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=False
    )
    expires_at = Column(DATETIME(fsp=6), nullable=False)
    claimed_user_id = Column(Integer, nullable=True)
    claimed_at = Column(DATETIME(fsp=6), nullable=True)
    pending_email = Column(
        VARCHAR(100, collation="utf8mb4_bin"),
        Computed(
            "CASE WHEN status='pending' THEN invitee_email ELSE NULL END",
            persisted=True,
        ),
        nullable=True,
    )
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    updated_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("invite_token_hash", name="uq_invitation_hash"),
        UniqueConstraint("team_id", "pending_email", name="uq_team_pending_email"),
        Index("idx_invitation_team_email", "team_id", "invitee_email", "status"),
        Index("idx_invitation_inviter", "invited_by_user_id", "created_at"),
        Index("idx_invitation_status", "team_id", "status", "created_at", "id"),
        Index("idx_invitation_expiry", "status", "expires_at"),
        Index("idx_invitation_claimed", "claimed_user_id"),
        ForeignKeyConstraint(["team_id"], ["teams.id"], name="fk_invitation_team"),
        ForeignKeyConstraint(
            ["invited_by_user_id"], ["users.id"], name="fk_invitation_inviter"
        ),
        ForeignKeyConstraint(
            ["claimed_user_id"], ["users.id"], name="fk_invitation_claimed"
        ),
        CheckConstraint(
            "team_role IN ('team_admin','team_member')", name="ck_invitation_role"
        ),
        CheckConstraint(
            "status IN ('pending','claimed','revoked','expired')",
            name="ck_invitation_status",
        ),
        CheckConstraint(
            "\n    CHAR_LENGTH(invitee_email) > 0 AND\n    BINARY invitee_email = BINARY LOWER(TRIM(invitee_email))",
            name="ck_invitation_email",
        ),
        CheckConstraint(
            "\n    (status='claimed' AND claimed_user_id IS NOT NULL AND claimed_at IS NOT NULL) OR\n    (status<>'claimed' AND claimed_user_id IS NULL AND claimed_at IS NULL)",
            name="ck_invitation_claim",
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
