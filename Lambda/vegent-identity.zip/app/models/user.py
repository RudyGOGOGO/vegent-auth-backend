from sqlalchemy import (
    Column,
    Integer,
    Text,
    JSON,
    Boolean,
    UniqueConstraint,
    CheckConstraint,
    Index,
    text,
)
from sqlalchemy.dialects.mysql import DATETIME, VARCHAR, CHAR
from sqlalchemy.orm import deferred
from app.db.base import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_name = Column(VARCHAR(50), nullable=False)
    password_hash = Column(VARCHAR(256), nullable=False)
    email = Column(VARCHAR(100, collation="utf8mb4_bin"), nullable=False)
    git_info = deferred(Column(JSON, nullable=True), raiseload=True)
    is_active = Column(Boolean, nullable=False, server_default=text("TRUE"))
    role = Column(VARCHAR(20), nullable=False, server_default=text("'user'"))
    auth_source = Column(VARCHAR(20), nullable=False, server_default=text("'password'"))
    preferences = Column(VARCHAR(4096), nullable=False, server_default=text("'{}'"))
    display_name = Column(VARCHAR(100), nullable=True)
    bio = Column(Text, nullable=True)
    needs_registration = Column(Boolean, nullable=False, server_default=text("FALSE"))
    token_version = Column(Integer, nullable=False, server_default=text("0"))
    unlock_token_hash = Column(
        CHAR(64, charset="ascii", collation="ascii_bin"), nullable=True
    )
    unlock_expires_at = Column(DATETIME(fsp=6), nullable=True)
    unlock_used_at = Column(DATETIME(fsp=6), nullable=True)
    created_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    updated_at = Column(
        DATETIME(fsp=6), nullable=False, server_default=text("CURRENT_TIMESTAMP(6)")
    )
    __table_args__ = (
        UniqueConstraint("user_name", name="uq_users_user_name"),
        UniqueConstraint("email", name="uq_users_email_lower"),
        UniqueConstraint("unlock_token_hash", name="uq_users_unlock_hash"),
        Index("idx_users_admin", "role", "is_active"),
        CheckConstraint("role IN ('admin','user')", name="ck_users_role"),
        CheckConstraint("token_version >= 0", name="ck_users_version"),
        CheckConstraint(
            "\n    CHAR_LENGTH(email) > 0 AND BINARY email = BINARY LOWER(TRIM(email))",
            name="ck_users_email",
        ),
        {
            "mysql_engine": "InnoDB",
            "mysql_charset": "utf8mb4",
            "mysql_collate": "utf8mb4_unicode_ci",
        },
    )
