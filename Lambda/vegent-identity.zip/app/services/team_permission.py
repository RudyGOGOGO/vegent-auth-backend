from app.models.user import User
from app.models.team import Team
from app.schemas.auth import ServiceError
from app.core.security import assert_current_actor
from app.services.team_members import active_member

MEMBER_ACTIONS = {"view", "view_members"}
ADMIN_ACTIONS = MEMBER_ACTIONS | {
    "edit",
    "view_invitations",
    "view_history",
    "invite",
    "revoke",
    "resend",
    "change_role",
    "remove_member",
}


def check_team_permission(user_id, team_id, required_action, *, db):
    user = db.get(User, user_id)
    team = db.get(Team, team_id)
    if not user or not user.is_active or user.needs_registration or not team:
        return False
    if required_action not in ADMIN_ACTIONS | {"deactivate"}:
        return False
    if user.role == "admin":
        return True
    if not team.is_active:
        return False
    row = active_member(db, team_id, user_id)
    return bool(
        row
        and (
            required_action in MEMBER_ACTIONS
            or row.team_role == "team_admin"
            and required_action in ADMIN_ACTIONS
        )
    )


def require_team_permission(actor, team_id, action, *, db):
    assert_current_actor(actor, db=db)
    if not check_team_permission(actor.user_id, team_id, action, db=db):
        raise ServiceError("FORBIDDEN", 403)
    return db.get(Team, team_id)
