import json
from sqlalchemy import select
from app.models.system_config import SystemConfig
from app.models.user import User
from app.schemas.auth import ServiceError
from app.core.security import get_password_hash
from app.services.team_members import transaction, utcnow, write_audit
from app.services.auth import issue_session, revoke_user_sessions


@transaction
def setup_initial_admin_password(password, iam_principal, *, db):
    config = db.scalar(
        select(SystemConfig)
        .where(SystemConfig.config_key == "admin_password_initialized")
        .with_for_update()
    )
    state = json.loads(config.config_value) if config else {}
    if not config or state.get("completed") is not False:
        raise ServiceError("STATE_CONFLICT", 409)
    user = db.scalar(
        select(User).where(User.id == state["admin_user_id"]).with_for_update()
    )
    if (
        not user
        or user.email != "wei.zhang11@verizon.com"
        or user.user_name != "wei.zhang11"
        or user.role != "admin"
        or not user.is_active
        or not user.needs_registration
    ):
        raise ServiceError("STATE_CONFLICT", 409)
    user.password_hash = get_password_hash(password)
    user.needs_registration = False
    revoke_user_sessions(user, db=db)
    config.config_value = json.dumps({"completed": True, "admin_user_id": user.id})
    write_audit(
        db,
        actor_user_id=user.id,
        action="bootstrap_completed",
        detail={"iam_principal": iam_principal},
    )
    return issue_session(user, db=db, now=utcnow())


def read_bootstrap_completed(*, db):
    config = db.scalar(
        select(SystemConfig).where(
            SystemConfig.config_key == "admin_password_initialized"
        )
    )
    return bool(config and json.loads(config.config_value).get("completed"))
