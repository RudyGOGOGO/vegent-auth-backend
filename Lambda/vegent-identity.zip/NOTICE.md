---
sidebar_position: 2
---
# Vegent Identity Notice

Copyright 2026 Verizon. This service is an independent implementation of the approved Vegent Identity contract. Application source and comments use English. Original reference repository files are not included in the service artifact. No original third-party copyright header is renamed as Verizon authorship.

The package includes third-party dependencies under their respective licenses. Preserve their distribution metadata and notices. The AWS RDS CA bundle is public trust material obtained from the official AWS truststore.
