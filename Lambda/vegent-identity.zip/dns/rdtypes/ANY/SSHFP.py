# Copyright (C) Dnspython Contributors, see LICENSE for text of ISC license

# Copyright (C) 2005-2007, 2009-2011 Nominum, Inc.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose with or without fee is hereby granted,
# provided that the above copyright notice and this permission notice
# appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND NOMINUM DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL NOMINUM BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
# OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import binascii
import struct

import dns.immutable
import dns.rdata
import dns.rdatatype


@dns.immutable.immutable
class SSHFP(dns.rdata.Rdata):
    """SSHFP record"""

    # See RFC 4255

    __slots__ = ["algorithm", "fp_type", "fingerprint"]

    # Fingerprint type registry: type 1 is SHA-1 (RFC 4255 Section 3.1.3) and
    # type 2 is SHA-256 (RFC 6594 Section 3.2).
    _fingerprint_length_by_type = {
        1: 20,  # SHA-1, RFC 4255 Section 3.1.3
        2: 32,  # SHA-256, RFC 6594 Section 3.2
    }

    def __init__(self, rdclass, rdtype, algorithm, fp_type, fingerprint):
        super().__init__(rdclass, rdtype)
        self.algorithm = self._as_uint8(algorithm)
        self.fp_type = self._as_uint8(fp_type)
        self.fingerprint = self._as_bytes(fingerprint, True)
        expected = self._fingerprint_length_by_type.get(self.fp_type)
        if expected is not None and len(self.fingerprint) != expected:
            raise ValueError("fingerprint length inconsistent with fingerprint type")

    def to_styled_text(self, style: dns.rdata.RdataStyle) -> str:
        fingerprint = dns.rdata._styled_hexify(self.fingerprint, style)
        return f"{self.algorithm} {self.fp_type} {fingerprint}"

    @classmethod
    def from_text(
        cls, rdclass, rdtype, tok, origin=None, relativize=True, relativize_to=None
    ):
        algorithm = tok.get_uint8()
        fp_type = tok.get_uint8()
        fingerprint = tok.concatenate_remaining_identifiers().encode()
        fingerprint = binascii.unhexlify(fingerprint)
        return cls(rdclass, rdtype, algorithm, fp_type, fingerprint)

    def _to_wire(self, file, compress=None, origin=None, canonicalize=False):
        header = struct.pack("!BB", self.algorithm, self.fp_type)
        file.write(header)
        file.write(self.fingerprint)

    @classmethod
    def from_wire_parser(cls, rdclass, rdtype, parser, origin=None):
        header = parser.get_struct("BB")
        fingerprint = parser.get_remaining()
        return cls(rdclass, rdtype, header[0], header[1], fingerprint)
