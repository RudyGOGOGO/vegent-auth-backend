from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE system_configs (\n  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  config_key VARCHAR(100) NOT NULL,\n  config_value VARCHAR(4096) NOT NULL DEFAULT '{}',\n  version INT NOT NULL DEFAULT 1,\n  updated_by INT NULL,\n  expires_at DATETIME(6) NULL,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)\n    ON UPDATE CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_system_config_key (config_key),\n  KEY idx_system_config_expiry (expires_at),\n  KEY idx_system_config_actor (updated_by),\n  CONSTRAINT fk_config_actor FOREIGN KEY (updated_by) REFERENCES users(id),\n  CONSTRAINT ck_system_config_json CHECK (JSON_VALID(config_value))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
