from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE teams (\n  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  team_name VARCHAR(100) NOT NULL,\n  slug VARCHAR(100) NOT NULL,\n  description TEXT NULL,\n  created_by_user_id INT NOT NULL,\n  is_active BOOLEAN NOT NULL DEFAULT TRUE,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)\n    ON UPDATE CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_teams_name (team_name),\n  UNIQUE KEY uq_teams_slug (slug),\n  KEY idx_teams_created_by (created_by_user_id),\n  CONSTRAINT fk_team_creator FOREIGN KEY (created_by_user_id) REFERENCES users(id),\n  CONSTRAINT ck_team_name CHECK (CHAR_LENGTH(TRIM(team_name)) BETWEEN 2 AND 100)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
