from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE team_members (\n  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n  team_id BIGINT NOT NULL,\n  user_id INT NOT NULL,\n  team_role VARCHAR(20) NOT NULL,\n  status VARCHAR(20) NOT NULL DEFAULT 'active',\n  invited_by_user_id INT NOT NULL,\n  joined_at DATETIME(6) NOT NULL,\n  removed_at DATETIME(6) NULL,\n  removed_by_user_id INT NULL,\n  active_user_id INT GENERATED ALWAYS AS\n    (CASE WHEN status='active' THEN user_id ELSE NULL END) STORED,\n  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),\n  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)\n    ON UPDATE CURRENT_TIMESTAMP(6),\n  UNIQUE KEY uq_team_active_user (team_id,active_user_id),\n  KEY idx_members_team (team_id,status,joined_at,id),\n  KEY idx_members_user (user_id,status,team_id),\n  KEY idx_members_inviter (invited_by_user_id,team_id,user_id),\n  KEY idx_members_remover (removed_by_user_id),\n  CONSTRAINT fk_member_team FOREIGN KEY (team_id) REFERENCES teams(id),\n  CONSTRAINT fk_member_user FOREIGN KEY (user_id) REFERENCES users(id),\n  CONSTRAINT fk_member_inviter FOREIGN KEY (invited_by_user_id) REFERENCES users(id),\n  CONSTRAINT fk_member_remover FOREIGN KEY (removed_by_user_id) REFERENCES users(id),\n  CONSTRAINT ck_member_role CHECK (team_role IN ('team_admin','team_member')),\n  CONSTRAINT ck_member_status CHECK (status IN ('active','removed')),\n  CONSTRAINT ck_member_removed CHECK (\n    (status='active' AND removed_at IS NULL AND removed_by_user_id IS NULL) OR\n    (status='removed' AND removed_at IS NOT NULL AND removed_by_user_id IS NOT NULL))\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    )


def downgrade():
    raise RuntimeError(
        "Destructive rollback is disabled; restore the compatible application version."
    )
