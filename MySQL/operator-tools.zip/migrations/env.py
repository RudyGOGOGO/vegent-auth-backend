import importlib
import os
from alembic import context
from sqlalchemy import text


def run_migrations_online():
    location = os.environ["VEGENT_OPERATOR_ADAPTER"]
    module, factory = location.split(":", 1)
    operator = getattr(importlib.import_module(module), factory)()
    approval = operator.verify_approval(
        os.environ["VEGENT_MIGRATION_APPROVAL"], "migrate", None
    )
    from datetime import datetime, timezone

    if (
        approval.operation != "migrate"
        or approval.expires_at <= datetime.now(timezone.utc).replace(tzinfo=None)
        or not approval.operator_principal
    ):
        raise RuntimeError("Migration approval required")
    with operator.open_session() as session:
        connection = session.connection()
        if (
            connection.dialect.name != "mysql"
            or connection.engine.url.database != approval.database_identity
        ):
            raise RuntimeError("Approved MySQL database required")
        if (
            connection.scalar(text("SELECT GET_LOCK('vegent_identity_migration',0)"))
            != 1
        ):
            raise RuntimeError("Migration already running")
        try:
            context.configure(connection=connection, target_metadata=None)
            with context.begin_transaction():
                context.run_migrations()
        finally:
            connection.execute(text("SELECT RELEASE_LOCK('vegent_identity_migration')"))
        session.commit()


if context.is_offline_mode():
    raise RuntimeError("Offline execution is disabled")
else:
    run_migrations_online()
